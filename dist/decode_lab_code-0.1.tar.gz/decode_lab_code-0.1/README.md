# decode_lab_code
 A python toolbox to support analyses performed in the DECODE lab at Nemours Childrens Hospital in Wilmington DE, led by A.Hernan and R.Scott

 This package is a work-in-progress and is in early development.

 Analysis requires caiman and the NeuroConv environments. Future requirements will include docker and pynapple
 